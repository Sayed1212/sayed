#sudo apt-get update
#sudo apt-get install git -y
wget -N https://download1519.mediafire.com/hqlix6b19bsg/we77oalq1ljtwtn/FCILuxorDjango.zip
unzip FCILuxorDjango.zip
cd WebProgDjango
python manage.py runserver

